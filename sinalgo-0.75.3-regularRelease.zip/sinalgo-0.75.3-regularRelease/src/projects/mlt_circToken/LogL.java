package projects.mlt_circToken;

public class LogL extends sinalgo.tools.logging.LogL{

}
