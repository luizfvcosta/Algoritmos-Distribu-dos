package projects.mlt_circToken.nodes.messages;

import java.awt.Color;

import sinalgo.nodes.messages.Message;

public class CircTokenMessage extends Message {
	public Color color; // the color the receiver should take 
	
	public int nextNodeID;
	
	
	@Override
	public Message clone() {
		
		// This is a read-only message! Receivers may not modify the message
		// If this is not the case, we need to return a clone of this msg.
		
		return this;
	}

}
