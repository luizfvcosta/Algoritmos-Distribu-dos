package projects.mlt_circToken.nodes.timers;

import sinalgo.nodes.Node;
import sinalgo.nodes.messages.Message;

public class SendTimer extends sinalgo.nodes.timers.Timer {

	private Message msg; // the msg to send
	private Node dest; // the node to send the msg to
	
	public SendTimer(Message msg, Node destination) {
		this.msg = msg;
		this.dest = destination;
	}
	
	@Override
	public void fire() {
		this.node.sendDirect(msg, dest);
	}

}
