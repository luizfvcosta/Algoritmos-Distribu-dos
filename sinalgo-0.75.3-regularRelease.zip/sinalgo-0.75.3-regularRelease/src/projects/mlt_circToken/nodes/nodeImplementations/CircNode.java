package projects.mlt_circToken.nodes.nodeImplementations;

import java.awt.Color;
import java.awt.Graphics;

import projects.mlt_circToken.nodes.messages.CircTokenMessage;
import sinalgo.configuration.Configuration;
import sinalgo.configuration.CorruptConfigurationEntryException;
import sinalgo.configuration.WrongConfigurationException;
import sinalgo.gui.helper.NodeSelectionHandler;
import sinalgo.gui.transformation.PositionTransformation;
import sinalgo.io.eps.EPSOutputPrintStream;
import sinalgo.nodes.Node;
import sinalgo.nodes.messages.Inbox;
import sinalgo.nodes.messages.Message;
import sinalgo.tools.Tools;


public class CircNode extends Node {
	
	//public int lamportInternalClock = 0;
	
	public boolean waiting = false;
	
	public boolean haveToken = false;
	
	
	@Override
	public void checkRequirements() throws WrongConfigurationException {
		// Nothing to do - we could check here, that proper models are set, and other settings are correct
	}

	@Override
	public void handleMessages(Inbox inbox) {
		while(inbox.hasNext()) {
			Message msg = inbox.next();
			if(msg instanceof CircTokenMessage) {
				CircTokenMessage m = (CircTokenMessage) msg;
				if(this.waiting) {
					this.haveToken = true;
					// print the message on output
					Tools.appendToOutput(ID +" have the token" + "\n");
				}
				else {
					CircNode nextNode = (CircNode) Tools.getNodeByID(ID + 1);
					sendColorMessage(Color.BLACK,nextNode );
					haveToken = true;
				}
				this.setColor(m.color); // set this node's color
			}
		}
	}


	private void sendColorMessage(Color c,Node i) {
		CircTokenMessage msg = new CircTokenMessage();
		msg.color = c;
		msg.nextNodeID = ID + 1;
		haveToken = false;
		Tools.appendToOutput(ID +" send the token to "+ ID + "\n");
		send(msg,i);
	}
	

		/**
	 * This popup method demonstrates how a message can be sent
	 * even when there is no edge between the sender and receiver  
	 */
	@NodePopupMethod(menuText="send DIRECT PINK")
	public void sendDirectPink() {
		Tools.getNodeSelectedByUser(new NodeSelectionHandler() {
			public void handleNodeSelectedEvent(Node n) {
				if(n == null) {
					return; // the user aborted
				}
				if(haveToken) {
					CircTokenMessage msg = new CircTokenMessage();
					msg.color = Color.pink;
					haveToken = false;
					Tools.appendToOutput(ID +" send the token to "+ n.ID + "\n");
					sendDirect(msg, n);
				}
			}
		}, "Select a node to which you want to send a direct 'PINK' message.");
	}

	@NodePopupMethod(menuText="Start")
	public void start() {
		// This sample project is designed for the round-based simulator. 
		// I.e. a node is only allowed to send a message when it is its turn.
		// To comply with this rule, we're not allowed to call the 
		// method 'SendMessage()' here, but need either to remember that the
		// user has clicked to send a message and then send it in the intervalStep()
		// manually. Here, we show a simpler and more elegant approach: 
		// Set a timer (with time 1), which will fire the next time this node is
		// handled. The defaultProject already contains a MessageTimer which can 
		// be used for exactly this purpose.
		haveToken = true;
		Tools.appendToOutput("Start Routing from node " + this.ID + "\n");
	}
	
	
	
	
	
	
	private boolean simpleDraw = false;
	
	@Override
	public void init() {
		if(Configuration.hasParameter("LaNode/simpleDraw")) {
			try {
				simpleDraw = Configuration.getBooleanParameter("LaNode/simpleDraw");
			} catch (CorruptConfigurationEntryException e) {
				Tools.fatalError("Invalid config field LaNode/simpleDraw: Expected a boolean.\n" + e.getMessage());
			}
		} else {
			simpleDraw = false;
		}
		// nothing to do here
	}

	@Override
	public void neighborhoodChange() {
		// not called in async mode!
	}

	@Override
	public void preStep() {
		// not called in async mode!
	}

	@Override
	public void postStep() {
		// not called in async mode!
	}
		
	private boolean drawRound = false;

	private boolean isDrawRound() {
		if(drawRound) {
			return true;
		}
		return false;
	}
	
	@NodePopupMethod(menuText="Draw as Circle")
	public void drawRound() {
		drawRound = !drawRound;
		Tools.repaintGUI();
	}

	@Override
	public String toString() {
		return "token: " + haveToken +"\nwaiting: " + waiting;
	}
	
	@Override
	public void draw(Graphics g, PositionTransformation pt, boolean highlight) {
		// overwrite the draw method to change how the GUI represents this node
		if(simpleDraw) {
			super.draw(g, pt, highlight);
		} else {
			if(isDrawRound()) {
				super.drawNodeAsDiskWithText(g, pt, highlight, Integer.toString(this.ID), 16, Color.WHITE);
			} else {
				super.drawNodeAsSquareWithText(g, pt, highlight, Integer.toString(this.ID), 16, Color.WHITE);
			}
		}
	}
	
	public void drawToPostScript(EPSOutputPrintStream pw, PositionTransformation pt) {
		if(isDrawRound()) {
			super.drawToPostScriptAsDisk(pw, pt, drawingSizeInPixels/2, getColor());
		} else {
			super.drawToPostscriptAsSquare(pw, pt, drawingSizeInPixels, getColor());
		}
	}
}
